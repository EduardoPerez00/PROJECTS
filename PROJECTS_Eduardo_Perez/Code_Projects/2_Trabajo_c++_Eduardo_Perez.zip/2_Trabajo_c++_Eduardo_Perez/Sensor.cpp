
// Includes
//#include <iostream>
#include "Persona.hpp"
#include "formato.hpp"

// para stringstream
#include <sstream>

// Para evitar todo el codigo de doctest al compilar.
// Util cuando se mezcla implementacion con pruebas en el mismo fichero
//#define DOCTEST_CONFIG_DISABLE
#include "doctest.h"

// Variables globales (mejor que no existan). Por ejemplo:
//int version_modulo = 1;

using namespace std;

//METODOS GET DE CADA UNO DE LAS VARIABLES COMPONENTES DE SENSOR Y ATEXTO()
int getId() const {
    return id;
}

std::string getNombre() const {
    return nombre;
}

int getMinConversor() const {
    return min_conversor;
}

int getMaxConversor() const {
    return max_conversor;
}

double getMinMagnitud() const {
    return min_magnitud;
}

double getMaxMagnitud() const {
    return max_magnitud;
}

std::string aTexto() const {
    return pformato->aTexto(this);
}
};

//PRUEBA DE DOCTEST DEL M�TODO aTexto()

TEST_CASE("Sensor - aTexto") {
    const FormatoSensor* formatoBreve = new FormatoBreve();
    const FormatoSensor* formatoLargo = new FormatoLargo();

    Sensor sensor1(0, "Temperatura", 0, 1023, -10.0, 100.0, formatoBreve);
    Sensor sensor2(1, "Humedad", 0, 100, 0.0, 5.0, formatoLargo);

    std::string textoEsperadoBreve = "Sensor(0, Temperatura)";
    std::string textoEsperadoLargo = "Sensor(id=1, nombre=Humedad, min_conversor=0, max_conversor=100, min_magnitud=0.0, max_magnitud=5.0).";

    CHECK(sensor1.aTexto() == textoEsperadoBreve);
    CHECK(sensor2.aTexto() == textoEsperadoLargo);

    delete formatoBreve;
    delete formatoLargo;
}



