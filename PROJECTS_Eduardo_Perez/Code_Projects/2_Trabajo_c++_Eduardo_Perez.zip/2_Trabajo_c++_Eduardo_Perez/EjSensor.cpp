
//Entrada/salida en C++
// para std::cin,cout,cerr; std::endl
#include <iostream>
//Entrada/salida en C y en C++
//#include <stdio.h>

//para EXIT_SUCCESS
#include <stdlib.h>

// para smart pointers: std::shared_ptr, std::make_shared, ...
#include <memory>

//cabecera/s de modulo/s usado/s

#include <string>

#include "Sensor.hpp"
#include "formato.hpp"

// espacio de nombres de C++
// para usar por ejemplo std::endl como endl
using namespace std;



int main() {
    // Crear un sensor de ejemplo
    const FormatoSensor* formato = new FormatoBreve();
    Sensor sensor(0, "Temperatura", 0, 1023, -10.0, 100.0, formato);

    // Crear un vector de muestras
    std::vector<int> muestras = { 500, 750, 1000 };

    // Obtener los valores reconvertidos a la magnitud f�sica
    std::vector<double> valores = valores_muestreo(sensor, muestras);

    // Imprimir los valores reconvertidos
    for (double valor : valores) {
        std::cout << valor << std::endl;
    }
    // Grabar los datos en un archivo de texto
    grabar_datos(sensor, valores, "datos.txt");

    delete formato;

    return 0;
}

//APARTADO 1.4 VALOR MUESTREO
double valor_muestreo(const Sensor& sensor, int muestra) {
    double factor = (sensor.max_magnitud - sensor.min_magnitud) / (sensor.max_conversor - sensor.min_conversor);
    return sensor.min_magnitud + (muestra - sensor.min_conversor) * factor;
}

std::vector<double> valores_muestreo(const Sensor& sensor, const std::vector<int>& muestras) {
    std::vector<double> valores;

    for (int muestra : muestras) {
        double valor = valor_muestreo(sensor, muestra);
        valores.push_back(valor);
    }

    return valores;
}
//PRUEBA DE DOCTEST VALOR MUESTREO
TEST_CASE("Sensor - Prueba de valor_muestreo") {
    const FormatoSensor* formato = new FormatoBreve();
    Sensor sensor(2, "Temperatura", 0, 100, -10.0, 10.0, formato);

    CHECK(valor_muestreo(sensor, 0) == -10.0);
    CHECK(valor_muestreo(sensor, 50) == 0.0);
    CHECK(valor_muestreo(sensor, 100) == 10.0);

    delete formato;
}

// APARTADO 1.5 GRABAR DATOS
void grabar_datos(const Sensor& sensor, const std::vector<double>& valores, const std::string& nombre_archivo) {
    std::ofstream archivo(nombre_archivo);

    // Escribir la informaci�n del sensor en la primera l�nea
    archivo << sensor.aTexto() << std::endl;

    // Escribir las muestras en l�neas separadas
    for (double valor : valores) {
        archivo << valor << std::endl;
    }

    archivo.close();
}
//PRUEBA DE DOCTEST PARA LA GRABACI�N DE ARCHIVOS
TEST_CASE("Sensor - Prueba de grabar_datos") {
    const FormatoSensor* formato = new FormatoLargo();
    Sensor sensor(4, "Iluminaci�n", 0, 1023, 0.0, 1000.0, formato);

    std::vector<double> valores = { 100.0, 200.0, 300.0 };
    std::string nombre_archivo = "datos.txt";

    grabar_datos(sensor, valores, nombre_archivo);

    std::ifstream archivo(nombre_archivo);
    std::string linea;
    std::getline(archivo, linea);  // Leer la primera l�nea del archivo

    std::string texto_esperado = "Sensor(id=4, nombre=Iluminaci�n, min_conversor=0, max_conversor=1023, min_magnitud=0.0, max_magnitud=1000.0).";
    CHECK(linea == texto_esperado);

    archivo.close();
    std::remove(nombre_archivo.c_str());  // Eliminar el archivo

    delete formato;
}