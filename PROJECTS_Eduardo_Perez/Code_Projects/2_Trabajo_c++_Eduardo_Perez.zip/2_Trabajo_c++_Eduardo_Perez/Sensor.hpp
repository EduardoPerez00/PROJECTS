// Para evitar la inclusion de este modulo mas de una vez.
// Pero pragma once no esta soportado en todos los compiladores
//#pragma once
#ifndef Sensor_h
#define Sensor_h


// Includes necesarios para usar este modulo
#include <string>
//#include "formato.hpp"
//Para resolver las dependencias circulares
class Formato;

using namespace std;

/** Clase para manejar datos de un sensor.
* Al constructor se le pasa un puntero a un objeto de tipo
*/
class Sensor {
private:
    int id;
    std::string nombre;
    int min_conversor;
    int max_conversor;
    double min_magnitud;
    double max_magnitud;
    const FormatoSensor* pformato;

public:
    Sensor(int id, const std::string& nombre, int min_conversor, int max_conversor, double min_magnitud, double max_magnitud, const FormatoSensor* pformato)
        : id(id), nombre(nombre), min_conversor(min_conversor), max_conversor(max_conversor),
        min_magnitud(min_magnitud), max_magnitud(max_magnitud), pformato(pformato) {}

    std::string aTexto() const {
        return pformato->a_texto(id, nombre, min_conversor, max_conversor, min_magnitud, max_magnitud);
    }
};
#endif // Sensor_h
