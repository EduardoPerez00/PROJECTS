// Para evitar la inclusion de este modulo mas de una vez.
// Pero pragma once no esta soportado en todos los compiladores
//#pragma once
#ifndef FORMATO_h
#define FORMATO_h


//#include "Sensor.hpp"
//Para resolver las dependencias circulares
class Sensor;

using namespace std;

/** Esta es una clase abstracta, no se puede instanciar
* puesto que tiene un metodo virtual puro.
* Es la base de todas las clases formato , tanto FormatoBreve como FormatoLargo
*/
class FormatoSensor {
public:
    virtual std::string aTexto(const Sensor* psensor) const = 0;
};



class FormatoBreve : public FormatoSensor {
public:
    virtual std::string aTexto(const Sensor* psensor) const;
};

class FormatoLargo : public FormatoSensor {
public:
    virtual std::string aTexto(const Sensor* psensor) const;
};

#endif  // FORMATO_h
