#include <iostream>
#include "formato.hpp"
#include "Sensor.hpp"

// para stringstream
#include <sstream>
// para string
#include <string>

// Para evitar todo el codigo de doctest al compilar.
// Util cuando se mezcla implementacion con pruebas en el mismo fichero
//#define DOCTEST_CONFIG_DISABLE

#include "doctest.h"

using namespace std;


//==========================
// Clase FormatoBreve
//==========================
class FormatoBreve : public FormatoSensor {
public:
    std::string aTexto(const Sensor* psensor) const override {
        return "Sensor(" + std::to_string(psensor->getId()) + ", " + psensor->getNombre() + ")";
    }
};
//PRUEBA DOCTEST PARA FORMATOBREVE.
TEST_CASE("Sensor - FormatoBreve") {
    const FormatoSensor* formato = new FormatoBreve();
    Sensor sensor(0, "Temperatura", 0, 1023, -10.0, 100.0, formato);

    std::string texto_esperado = "Sensor(0, Temperatura)";
    CHECK(sensor.aTexto() == texto_esperado);

    delete formato;
}

//==========================
// Clase FormatoLargo
//==========================

class FormatoLargo : public FormatoSensor {
public:
    std::string aTexto(const Sensor* psensor) const override {
        return "Sensor(" + std::to_string(psensor->getId()) + "
            ", nombre=" + psensor->getNombre() +
            ", min_conversor=" + std::to_string(psensor->getMinConversor()) +
            ", max_conversor=" + std::to_string(psensor->getMaxConversor()) +
            ", min_magnitud=" + std::to_string(psensor->getMinMagnitud()) +
            ", max_magnitud=" + std::to_string(psensor->getMaxMagnitud()) + ").";
    }
};
//PRUEBA DOCTEST PARA FORMATOLARGO.
TEST_CASE("Sensor - FormatoLargo") {
    const FormatoSensor* formato = new FormatoLargo();
    Sensor sensor(1, "Humedad", 0, 100, 0.0, 5.0, formato);

    std::string texto_esperado = "Sensor(id=1, nombre=Humedad, min_conversor=0, max_conversor=100, min_magnitud=0.0, max_magnitud=5.0).";
    CHECK(sensor.aTexto() == texto_esperado);

    delete formato;
}

