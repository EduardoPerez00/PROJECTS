
#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN  // This tells doctest to provide a main() - only do this in one cpp file
#include "doctest.h"

