import cv2
import auxiliarfunctlab3 as l3
import matplotlib.pyplot as plt
import numpy as np
import SIFTmatching as sif

figure_1_id = 1
figure_2_id = 2

img1 = cv2.cvtColor(cv2.imread("image1.png"), cv2.COLOR_BGR2RGB)
img2 = cv2.cvtColor(cv2.imread("image2.png"), cv2.COLOR_BGR2RGB)


if __name__ == '__main__':
    np.set_printoptions(precision=4, linewidth=1024, suppress=True)

    # Rutas de las imágenes
    timestamp1 = '1403715282262142976'
    timestamp2 = '1403715413262142976'

    path_image_1 = 'image1.png'
    path_image_2 = 'image2.png'

    # Leer imágenes
    image_pers_1 = cv2.imread(path_image_1)
    image_pers_2 = cv2.imread(path_image_2)

    # Extracción de características
    sift = cv2.SIFT_create(nfeatures=0, nOctaveLayers=5, contrastThreshold=0.01, edgeThreshold=20, sigma=0.7)
    keypoints_sift_1, descriptors_1 = sift.detectAndCompute(image_pers_1, None)
    keypoints_sift_2, descriptors_2 = sift.detectAndCompute(image_pers_2, None)

    distRatio = 0.8
    minDist = 100
    matchesList = sif.matchWith2NDRR(descriptors_1, descriptors_2, distRatio, minDist)
    dMatchesList = sif.indexMatrixToMatchesList(matchesList)
    dMatchesList = sorted(dMatchesList, key=lambda x: x.distance)

    # Mostrar las primeras 30 coincidencias
    plt.figure(3)
    imgMatched = cv2.drawMatches(image_pers_1, keypoints_sift_1, image_pers_2, keypoints_sift_2, dMatchesList[:30],
                                 None,
                                 flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS and cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    plt.imshow(imgMatched, cmap='gray', vmin=0, vmax=255)
    plt.draw()
    plt.waitforbuttonpress()

    # Conversión de DMatches a lista de Python
    matchesList = sif.matchesListToIndexMatrix(dMatchesList)

    # Puntos emparejados en formato numpy a partir de la lista de DMatches
    srcPts = np.float32([keypoints_sift_1[m.queryIdx].pt for m in dMatchesList]).reshape(len(dMatchesList), 2)
    dstPts = np.float32([keypoints_sift_2[m.trainIdx].pt for m in dMatchesList]).reshape(len(dMatchesList), 2)

    # Puntos emparejados en coordenadas homogéneas
    mh1 = np.vstack((srcPts.T, np.ones((1, srcPts.shape[0]))))
    mh2 = np.vstack((dstPts.T, np.ones((1, dstPts.shape[0]))))

    print(mh1)
    print(mh2)

    nElements = mh1.shape[1]

    # Parámetros de selección de muestras aleatorias
    inliersSigma = 1  # Desviación estándar de los valores internos

    # Número de intentos m para RANSAC
    nAttempts = 1000
    print('nAttempts = ' + str(nAttempts))

    # Ejecutar RANSAC para estimar la homografía
    H, MaximumVotes, bestx1, bestx2 = l3.ransac_homography(mh1, mh2, nAttempts, inliersSigma)
    print(MaximumVotes)
    print(H)

    # Ejecutar RANSAC para estimar la matriz fundamental
    F, MaximumVotes, bestx1, bestx2 = l3.ransac_fundamental(mh1, mh2, nAttempts, inliersSigma)
    print(MaximumVotes)
    print(F)
    l3.draw_epipolar_lines(F, bestx1, bestx2, image_pers_1, image_pers_2)


    #F_21_test =np.array[ 11131921 -359.7714    1.    ]
   
    
# Epipole provided by matches in lab2 = Epipole: [ 882.1902 -169.3164    1.    ] to compare .
# Distance entre el epipolo resultado con el de ground truth .