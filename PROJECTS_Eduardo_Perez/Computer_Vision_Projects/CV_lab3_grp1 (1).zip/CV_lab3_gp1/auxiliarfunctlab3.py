import matplotlib.pyplot as plt
import numpy as np
import cv2
import random

figure_1_id = 1
figure_2_id = 2

#Load the 2 images
img1 = cv2.cvtColor(cv2.imread("image1.png"), cv2.COLOR_BGR2RGB)
img2 = cv2.cvtColor(cv2.imread("image2.png"), cv2.COLOR_BGR2RGB)


def get_random_color():
    """
  Generate a random color represented as an RGB tuple.

  - Input: None

  - Output:
    A tuple representing a random color, where each component is in the range [0, 1].

  This function generates a random color by selecting random values for the red (R), green (G), and blue (B) components. The resulting color is represented as an RGB tuple, with each component ranging between 0 and 1. It is useful for assigning random colors to elements in various visualization and graphics applications.
 """
    R = random.uniform(0, 1)
    G = random.uniform(0, 1)
    B = random.uniform(0, 1)
    return (R, G, B)


# Calculate the geometric distance between estimated points and original points
def euclideanDistance(m1, m2, h):
    """
    Calculate the Euclidean distance between two 3D points represented in homogeneous coordinates after applying a geometric transformation.
    
    - Inputs:
        m1: A 3xN numpy array representing estimated points in homogeneous coordinates, where N is the number of estimated points. Each column of m1 represents a 3D point.
        m2: A 3xN numpy array representing original points in homogeneous coordinates, corresponding to the estimated points.
        h: A 3x3 transformation matrix used to relate the estimated points to the original points through a geometric transformation.
    
    - Output:
        distance: The Euclidean distance between the transformed estimated points and the original points, representing the geometric difference.
 """

    estimatep2 = h @ m1.T
    estimatep2 = estimatep2 / estimatep2[2]
    error = m2.T - estimatep2

    return np.linalg.norm(error)  # Euclidean distance


def draw_homography_points(H, info):
    plt.figure(figure_1_id)
    plt.imshow(img1)
    plt.title('Click a point in the image! (middle button to exit)')

    plt.figure(figure_2_id)
    plt.imshow(img2)
    plt.title('Epipolar lines. (Click to continue...)')
    while True:  # Infinite loop taking clicked points in image 1
        plt.figure(figure_2_id)
        plt.title(f'Homography points drawn with {info}. (Click to continue...)')
        plt.figure(figure_1_id)
        coord_clicked_point = plt.ginput(1, show_clicks=False)  # Get coordinates
        if not coord_clicked_point:  # Right click pressed -> exit loop
            plt.close(figure_1_id)
            plt.close(figure_2_id)
            break
        p_clicked = np.array([coord_clicked_point[0][0], coord_clicked_point[0][1]])

        random_color = get_random_color()  # Get random color

        # Draw clicked point's homography in image 2
        plt.plot(p_clicked[0], p_clicked[1], '+', color=random_color, markersize=15)
        plt.text(p_clicked[0], p_clicked[1], "({0:.2f}, {1:.2f})".format(p_clicked[0], p_clicked[1]), fontsize=10,
                 color=random_color)
        plt.draw()  # Drawing figure 1
        plt.figure(figure_2_id)
        point = np.array([p_clicked[0], p_clicked[1], 1.])

        H_point = H @ point
        H_point = H_point / H_point[2]
        plt.plot(H_point[0], H_point[1], '+', color=random_color, markersize=15)
        plt.text(H_point[0], H_point[1], "({0:.2f}, {1:.2f})".format(H_point[0], H_point[1]), fontsize=10,
                 color=random_color)

        plt.draw()  # Drawing figure 2
        plt.waitforbuttonpress()


def H_from_points(x1_matches, x2_matches):
    """ Find homography H, such that fp is mapped to tp
        using the linear DLT method. Points are conditioned
        automatically. """

    if x1_matches.shape != x2_matches.shape:
        raise RuntimeError('number of points do not match')

    # create matrix for linear method, 2 rows for each correspondence pair
    num_matches = x1_matches.shape[1]
    C = np.zeros((2 * num_matches, 9))
    for i in range(num_matches):
        C[2 * i] = [-x1_matches[0][i], -x1_matches[1][i], -1, 0, 0, 0, x2_matches[0][i] * x1_matches[0][i],
                    x2_matches[0][i] * x1_matches[1][i], x2_matches[0][i]]
        C[2 * i + 1] = [0, 0, 0, -x1_matches[0][i], -x1_matches[1][i], -1, x2_matches[1][i] * x1_matches[0][i],
                        x2_matches[1][i] * x1_matches[1][i], x2_matches[1][i]]

    _, _, V = np.linalg.svd(C)
    H = V[8].reshape((3, 3))

    # normalize and return
    return H / H[2, 2]


def display_best_inliers(bestx1, bestx2):
    """
Display the best inlier points on two images and label them.

 - Inputs:
    bestx1: A numpy array containing the coordinates of inlier points in the first image.
    bestx2: A numpy array containing the corresponding coordinates of inlier points in the second image.

 - Output: None

 The function displays two images (image1 and image2) and plots inlier points from the provided sets of points. Each inlier point is marked with a cross and labeled with its coordinates. Random colors are used for visual differentiation. This function is useful for visualizing inliers after a geometric transformation or correspondence matching has been performed.
 """

    plt.figure(figure_1_id)
    plt.imshow(img1)
    plt.figure(figure_2_id)
    plt.imshow(img2)
    for i in range(bestx1.shape[0]):
        random_color = get_random_color()  # Get random color
        plt.figure(figure_1_id)
        plt.plot(bestx1[i, 0], bestx1[i, 1], '+', color=random_color, markersize=15)
        plt.text(bestx1[i, 0], bestx1[i, 1], "({0:.2f}, {1:.2f})".format(bestx1[i, 0], bestx1[i, 1]), fontsize=10, color=random_color)
        plt.draw()  # Drawing figures

        plt.figure(figure_2_id)
        plt.plot(bestx2[i, 0], bestx2[i, 1], '+', color=random_color, markersize=15)
        plt.text(bestx2[i, 0], bestx2[i, 1], "({0:.2f}, {1:.2f})".format(bestx2[i, 0], bestx2[i, 1]), fontsize=10, color=random_color)
        plt.draw()  # Drawing figures

    plt.show()


def ransac_homography(x1, x2, nAttempts, inliersSigma):
    """
 Use the RANSAC algorithm to estimate a homography matrix between two sets of corresponding points while identifying inliers.

 - Inputs:
    x1: A 2xN numpy array containing the coordinates of points in the first set.
    x2: A 2xN numpy array containing the corresponding coordinates of points in the second set.
    nAttempts: The number of RANSAC iterations to perform.
    inliersSigma: The threshold for considering a point as an inlier based on its Euclidean distance to the estimated homography.

 -  Output:
    finalH: The estimated 3x3 homography matrix.
    nVotesMax: The number of inliers for the best homography estimation.
    best_x1_inliers: A numpy array of inlier points in the first set.
    best_x2_inliers: A numpy array of corresponding inlier points in the second set.

 The function uses the RANSAC algorithm to robustly estimate a homography matrix between two sets of corresponding points (x1 and x2). It iteratively selects random subsets of points, computes homographies, and identifies inliers based on a specified threshold. The final homography with the highest number of inliers is returned along with the inlier points in both sets for visualization.
 """

    RANSACThreshold = 3 * inliersSigma
    nVotesMax = 0

    finalH = None

    for kAttempt in range(nAttempts):

        # Find 4 random points to compute the homography
        r = []
        for i in range(4):
            r.append(random.randrange(x1.shape[1]))

        xSubSel1 = np.array([x1[:, r[0]], x1[:, r[1]], x1[:, r[2]], x1[:, r[3]]])
        xSubSel2 = np.array([x2[:, r[0]], x2[:, r[1]], x2[:, r[2]], x2[:, r[3]]])

        # Compute Homography using our 4 random selections
        h = H_from_points(xSubSel1.T, xSubSel2.T)

        # Computing the distance from the points to the GT
        res2 = []
        for i in range(x1.shape[1]):
            res = euclideanDistance(x1[:, i], x2[:, i], h)
            res2.append(res)

        votes = np.abs(res2) < RANSACThreshold  # votes
        nVotes = np.sum(votes)  # Number of votes

        if nVotes > nVotesMax:  # Si supera al anterior máximo, actualizamos
            nVotesMax = nVotes
            votesMax = votes
            finalH = h
            best_x1_inliers = xSubSel1
            best_x2_inliers = xSubSel2

    draw_homography_points(finalH, "H")
    display_best_inliers(best_x1_inliers, best_x2_inliers)

    return finalH, nVotesMax, best_x1_inliers, best_x2_inliers


def compute_fundamental(x1, x2):
    """    Computes the fundamental matrix from corresponding points
        (x1,x2 3*n arrays) using the 8 point algorithm.
        Each row in the A matrix below is constructed as
        [x'*x, x'*y, x', y'*x, y'*y, y', x, y, 1] """

    n = x1.shape[1]
    if x2.shape[1] != n:
        raise ValueError("Number of points don't match.")

    # build matrix for equations
    A = np.zeros((n, 9))
    for i in range(n):
        A[i] = [x1[0, i] * x2[0, i], x1[0, i] * x2[1, i], x1[0, i] * x2[2, i],
                x1[1, i] * x2[0, i], x1[1, i] * x2[1, i], x1[1, i] * x2[2, i],
                x1[2, i] * x2[0, i], x1[2, i] * x2[1, i], x1[2, i] * x2[2, i]]

    # compute linear least square solution
    U, S, V = np.linalg.svd(A)
    F = V[-1].reshape(3, 3)

    # constrain F
    # make rank 2 by zeroing out last singular value
    U, S, V = np.linalg.svd(F)
    S[2] = 0
    F = np.dot(U, np.dot(np.diag(S), V))

    return F / F[2, 2]


def compute_epipole(F):
    _, _, V = np.linalg.svd(F)
    e = V[-1]  # Get the solution
    e = e / e[2]  # Normalize
    # print(f'Epipole: ({e[0]},{e[1]})')
    return e


def draw_epipolar_lines(F, info):
    plt.figure(figure_1_id)
    plt.imshow(img1)
    plt.title('Click a point in the image! (middle button to exit)')

    plt.figure(figure_2_id)
    plt.imshow(img2)
    plt.title('Epipolar lines. (Click to continue...)')
    print(f'Epipole: {compute_epipole(F.T)}')
    while True:  # Infinite loop taking clicked points in image 1

        plt.figure(figure_2_id)
        plt.title(f'Epipolar lines drawn with {info}. (Click to continue...)')

        plt.figure(figure_1_id)
        coord_clicked_point = plt.ginput(1, show_clicks=False)  # Get clicked coordinates

        if not coord_clicked_point:  # Right click pressed -> exit loop
            plt.close(figure_1_id)
            plt.close(figure_2_id)
            break

        p_clicked = np.array([coord_clicked_point[0][0], coord_clicked_point[0][1]])

        random_color = get_random_color()  # Get random color

        # Draw clicked point's epipolar line in image 2
        plt.plot(p_clicked[0], p_clicked[1], '+', color=random_color, markersize=15)
        plt.text(p_clicked[0], p_clicked[1], "({0:.2f}, {1:.2f})".format(p_clicked[0], p_clicked[1]), fontsize=10,
                 color=random_color)
        plt.draw()  # Drawing figure 1

        plt.figure(figure_2_id)
        point = np.array([p_clicked[0], p_clicked[1], 1.])
        # line equation  => a*x + b*y + c = 0
        line = F @ point  # Compute the epipolar line
        print("Line equation: {0:.2f}*x + {1:.2f}*y + {2:.2f} = 0.".format(line[0], line[1], line[2]))

        p_l_y = np.array([0, -line[2] / line[1]])  # Intersection of the line with the axis Y (x=0)
        p_l_x = np.array([-line[2] / line[0], 0])  # Intersection point of the line with the axis X (y=0)

        # Draw the line segment p_l_x to  p_l_y
        plt.axline(p_l_y, p_l_x, color=random_color)

        e = compute_epipole(F.T)
        plt.plot(e[0], e[1], '+', color='g', markersize=15)
        plt.text(e[0], e[1], "Epipole ({0:.2f}, {1:.2f})".format(e[0], e[1]), fontsize=10, color='g')
        plt.draw()  # Drawing figure 2

        plt.waitforbuttonpress()


def ransac_fundamental(x1, x2, nAttempts, inliersSigma):
    """
 Use the RANSAC algorithm to estimate the fundamental matrix between two sets of corresponding points while identifying inliers.

 - Inputs:
    x1: A 2xN numpy array containing the coordinates of points in the first set.
    x2: A 2xN numpy array containing the corresponding coordinates of points in the second set.
    nAttempts: The number of RANSAC iterations to perform.
    inliersSigma: The threshold for considering a point as an inlier based on its distance to the epipolar line.

 - Output:
    finalF: The estimated 3x3 fundamental matrix.
    nVotesMax: The number of inliers for the best fundamental matrix estimation.
    best_x1_inliers: A numpy array of inlier points in the first set.
    best_x2_inliers: A numpy array of corresponding inlier points in the second set.

 The function uses the RANSAC algorithm to robustly estimate the fundamental matrix between two sets of corresponding points (x1 and x2). It iteratively selects random subsets of points, computes fundamental matrices, and identifies inliers based on a specified threshold. The final fundamental matrix with the highest number of inliers is returned, along with the inlier point sets for visualization.
 """

    RANSACThreshold = 3 * inliersSigma
    nVotesMax = 0

    finalH = None

    for kAttempt in range(nAttempts):

        # Find 8 random points to compute the fundamental
        r = []
        for i in range(8):
            r.append(random.randrange(x1.shape[1]))

        xSubSel1 = np.array([x1[:, r[0]], x1[:, r[1]], x1[:, r[2]], x1[:, r[3]], x1[:, r[4]], x1[:, r[5]], x1[:, r[6]], x1[:, r[7]]])
        xSubSel2 = np.array([x2[:, r[0]], x2[:, r[1]], x2[:, r[2]], x2[:, r[3]], x2[:, r[4]], x2[:, r[5]], x2[:, r[6]], x2[:, r[7]]])

        # Compute Homography using our 8 random selections
        F = compute_fundamental(xSubSel2.T, xSubSel1.T)

        # Computing the distance from the points to the GT
        res2 = []
        for i in range(x1.shape[1]):
            line = F @ x1[:, i]  # Compute the epipolar line
            p_l_y = np.array([0, -line[2] / line[1]])  # Intersection of the line with the axis Y (x=0)
            p_l_x = np.array([-line[2] / line[0], 0])  # Intersection point of the line with the axis X (y=0)
            res = np.linalg.norm(np.cross(p_l_y - p_l_x,  p_l_x - x2[0:2, i])) / np.linalg.norm(p_l_y - p_l_x)
            res2.append(res)

        votes = np.abs(res2) < RANSACThreshold  # votes
        nVotes = np.sum(votes)  # Number of votes

        if nVotes > nVotesMax:  # Si supera al anterior máximo, actualizamos
            nVotesMax = nVotes
            votesMax = votes
            finalF = F
            best_x1_inliers = xSubSel1
            best_x2_inliers = xSubSel2


    draw_epipolar_lines(finalF, "F")
    display_best_inliers(best_x1_inliers, best_x2_inliers)

    return finalF, nVotesMax, best_x1_inliers, best_x2_inliers

