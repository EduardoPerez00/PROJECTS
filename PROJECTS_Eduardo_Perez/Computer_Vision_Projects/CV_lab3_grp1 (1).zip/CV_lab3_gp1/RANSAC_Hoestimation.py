import numpy as np
import cv2
import auxiliarfunctlab3 as l3
import SIFTmatching as sif
# Definición de las figuras y carga de las imágenes
figure_1_id = 1
figure_2_id = 2
#Cargar las imagenes
img1 = cv2.cvtColor(cv2.imread("image1.png"), cv2.COLOR_BGR2RGB)
img2 = cv2.cvtColor(cv2.imread("image2.png"), cv2.COLOR_BGR2RGB)

if __name__ == '__main__':
    np.set_printoptions(precision=4, linewidth=1024, suppress=True)

    # Cargar datos desde el archivo NPZ
    path = './image1_image2_matches.npz'
    npz = np.load(path)

    # Crear listas para almacenar puntos correspondientes
    x1_correspondences = np.array([[], []])
    x2_correspondences = np.array([[], []])

    # Iterar a través de la longitud de las correspondencias npz.f.matches
    for i in range(npz.f.matches.shape[0]):
        if npz.f.matches[i] != -1:
            # Crear puntos correspondientes en imágenes 1 y 2
            point_a = np.array([[npz.f.keypoints0[i, 0]], [npz.f.keypoints0[i, 1]]])
            point_b = np.array([[npz.f.keypoints1[npz.f.matches[i], 0]], [npz.f.keypoints1[npz.f.matches[i], 1]]])

            # Agregar puntos correspondientes a las listas
            x1_correspondences = np.append(x1_correspondences, point_a, axis=1)
            x2_correspondences = np.append(x2_correspondences, point_b, axis=1)

    # Agregar una fila de unos para representar coordenadas homogéneas
    x1_correspondences = np.vstack((x1_correspondences, np.ones((1, x1_correspondences.shape[1]))))
    x2_correspondences = np.vstack((x2_correspondences, np.ones((1, x2_correspondences.shape[1]))))

    # Parámetros de la selección de muestras aleatorias
    inliersSigma = 1  # Desviación estándar de inliers

    # Número de intentos para RANSAC
    nAttempts = 1000
    print('nAttempts = ' + str(nAttempts))

    # Ejecutar RANSAC para estimar homografía
    estimated_H, max_inlier_votes, best_x1_inliers, best_x2_inliers = l3.ransac_homography(x1_correspondences, x2_correspondences, nAttempts, inliersSigma)
    print(max_inlier_votes)
    print(estimated_H)


    nAttempts = 1000
    # Ejecutar RANSAC para estimar matriz fundamental
    estimated_F, max_inlier_votes, best_x1_inliers, best_x2_inliers = l3.ransac_fundamental(x1_correspondences, x2_correspondences, nAttempts, inliersSigma)
    print(max_inlier_votes)
    print(estimated_F)

    # Imprimir las mejores correspondencias encontradas
    print(best_x1_inliers)
    print(best_x2_inliers)




